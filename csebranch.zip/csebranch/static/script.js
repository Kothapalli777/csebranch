let btnBack = document.querySelector('button');
btnBack.addEventListener('click', () => {
    window.history.back();
});